Installation Command:

sh /sdcard/AngleDriver/Execute.sh

⬇️

sh /storage/emulated/0/AngleDriver/Execute.sh

Deletion Command:

sh /sdcard/AngleDriver/Remove.sh

⬇️

sh /storage/emulated/0/AngleDriver/Remove.sh